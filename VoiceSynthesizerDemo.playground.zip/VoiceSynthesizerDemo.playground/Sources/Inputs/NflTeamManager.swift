import Foundation

public struct NflTeam {
    let name: String
    let city: String
    
    public init(name: String, city: String) {
        self.name = name
        self.city = city
    }
}

public class NflTeamManager: CommandResponseAbstractClass {
    public override init() {
    }
    override public func successfulResponse(command: String, response: String) -> String {
        return "The \(command) play their home games in \(response)"
    }
    override public func commandNotFoundResponse(command: String) -> String {
        return "Sorry, but there is no NFL team called the \(command)"
    }
    override public func loadCommandResponse() -> [CommandResponse] {
        return NflTeamManager.nflTeamData.map {
            CommandResponse(command: $0.name, response: $0.city) }
    }
    
    /*
     "San Francisco 49ers" : "SF",
     "Chicago Bears" : "CHI",
     "Cincinnati Bengals" : "CIN",
     "Buffalo Bills" : "BUF",
     "Denver Broncos" : "DEN",
     "Cleveland Browns" : "CLE",
     "Arizona Cardinals" : "ARI",
     "Los Angeles Chargers" : "LAC",
     "Kansas City Chiefs" : "KC",
     "Indianapolis Colts" : "IND",
     "Dallas Cowboys" : "DAL",
     "Miami Dolphins" : "MIA",
     "Philadelphia Eagles" : "PHI",
     "Atlanta Falcons" : "ATL",
     "New York Giants" : "NYG",
     "Jacksonville Jaguars" : "JAC",
     "New York Jets" : "NYJ",
     "Detroit Lions" : "DET",
     "Green Bay Packers" : "GB",
     "Carolina Panthers" : "CAR",
     "New England Patriots" : "NEP",
     "Oakland Raiders" : "OAK",
     "Los Angeles Rams" : "LAR",
     "Baltimore Ravens" : "BAL",
     "Washington Redskins" : "WAS",
     "New Orleans Saints" : "NO",
     "Seattle Seahawks" : "SEA",
     "Pittsburgh Steelers" : "PIT",
     "Tampa Bay Buccaneers" : "TB",
     "Houston Texans" : "HOU",
     "Tennessee Titans" : "TEN",
     "Minnesota Vikings" : "MIN"]
     
     */
    
    public static let nflTeamData = [
        (name: "49ers", city: "San Francisco"),
        (name: "Bears", city: "Chicago"),
        (name: "Bengals", city: "Cincinnati"),
        (name: "Bills", city: "Buffalo"),
        (name: "Broncos", city: "Denver"),
        (name: "Browns", city: "Cleveland"),
        (name: "Cardinals", city: "Arizona"),
        (name: "Chargers", city: "Los Angeles"),
        (name: "Chiefs", city: "Kansas City"),
        (name: "Colts", city: "Indianapolis"),
        (name: "Cowboys", city: "Dallas"),
        (name: "Dolphins", city: "Miami"),
        (name: "Eagles", city: "Philadelphia"),
        (name: "Falcons", city: "Atlanta"),
        (name: "Giants", city: "New York"),
        (name: "Jaguars", city: "Jacksonville"),
        (name: "Jets", city: "New York"),
        (name: "Lions", city: "Detroit"),
        (name: "Packers", city: "Green Bay"),
        (name: "Panthers", city: "Carolina"),
        (name: "Patriots", city: "New England"),
        (name: "Raiders", city: "Oakland"),
        (name: "Ravens", city: "Baltimore"),
        (name: "Redskins", city: "Washington"),
        (name: "Saints", city: "New Orleans"),
        (name: "Seahawks", city: "Seattle"),
        (name: "Steelers", city: "Pittsburgh"),
        (name: "Buccaneers", city: "Tampa Bay"),
        (name: "Texans", city: "Houston"),
        (name: "Titans", city: "Tennessee"),
        (name: "Vikings", city: "Minnesota")
    ]
}

