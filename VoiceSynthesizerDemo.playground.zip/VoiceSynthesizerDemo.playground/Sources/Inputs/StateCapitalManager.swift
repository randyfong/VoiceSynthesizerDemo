import Foundation

public struct StateCapital {
    let state: String
    let capital: String
    
    public init(state: String, capital: String) {
        self.state = state
        self.capital = capital
    }
}

public class StateCapitalManager: CommandResponseAbstractClass {
    public override init() {
    }
    override public func successfulResponse(command: String, response: String) -> String {
        return "The capital of \(command) is \(response)"
    }
    override public func commandNotFoundResponse(command: String) -> String {
        return "Sorry, but there is no state in the US named \(command)"
    }
    override public func loadCommandResponse() -> [CommandResponse] {
        return StateCapitalManager.stateCapitalData.map {
            CommandResponse(command: $0.state, response: $0.name) }
    }
    
    public static let stateCapitalData = [
        (name: "Montgomery", state: "Alabama"),
        (name: "Juneau", state: "Alaska"),
        (name: "Phoenix", state: "Arizona"),
        (name: "Little Rock", state: "Arkansas"),
        (name: "Sacramento", state: "California"),
        (name: "Denver", state: "Colorado"),
        (name: "Hartford", state: "Connecticut"),
        (name: "Dover", state: "Delaware"),
        (name: "Tallahassee", state: "Florida"),
        (name: "Atlanta", state: "Georgia"),
        (name: "Honolulu", state: "Hawaii"),
        (name: "Boise", state: "Idaho"),
        (name: "Springfield", state: "Illinois"),
        (name: "Indianapolis", state: "Indiana"),
        (name: "Des Moines", state: "Iowa"),
        (name: "Topeka", state: "Kansas"),
        (name: "Frankfort", state: "Kentucky"),
        (name: "Baton Rouge", state: "Louisiana"),
        (name: "Augusta", state: "Maine"),
        (name: "Annapolis", state: "Maryland"),
        (name: "Boston", state: "Massachusetts"),
        (name: "Lansing", state: "Michigan"),
        (name: "Saint Paul", state: "Minnesota"),
        (name: "Jackson", state: "Mississippi"),
        (name: "Jefferson City", state: "Missouri"),
        (name: "Helena", state: "Montana"),
        (name: "Lincoln", state: "Nebraska"),
        (name: "Carson City", state: "Nevada"),
        (name: "Concord", state: "New Hampshire"),
        (name: "Trenton", state: "New Jersey"),
        (name: "Santa Fe", state: "New Mexico"),
        (name: "Albany", state: "New York"),
        (name: "Raleigh", state: "North Carolina"),
        (name: "Bismarck", state: "North Dakota"),
        (name: "Columbus", state: "Ohio"),
        (name: "Oklahoma City", state: "Oklahoma"),
        (name: "Salem", state: "Oregon"),
        (name: "Harrisburg", state: "Pennsylvania"),
        (name: "Providence", state: "Rhode Island"),
        (name: "Columbia", state: "South Carolina"),
        (name: "Pierre", state: "South Dakota"),
        (name: "Nashville", state: "Tennessee"),
        (name: "Austin", state: "Texas"),
        (name: "Salt Lake City", state: "Utah"),
        (name: "Montpelier", state: "Vermont"),
        (name: "Richmond", state: "Virginia"),
        (name: "Olympia", state: "Washington"),
        (name: "Charleston", state: "West Virgina"),
        (name: "Madison", state: "Wisconsin"),
        (name: "Cheyenne", state: "Wyoming")
    ]
}
