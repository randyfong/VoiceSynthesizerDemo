//
//  VoiceSynthesizer.swift
//  VoiceSynthesizerDemo
//
//  Created by Randy Fong on 5/23/19.
//  Copyright © 2019 Randall Fong Inc. All rights reserved.
//

import Foundation
import AVFoundation

public class VoiceSynthesizer {
    
    // MARK: - Public Properties
    public var commandResponseBase: CommandResponseAbstractClass! {
        didSet {
            commandResponse = commandResponseBase.loadCommandResponse()
        }
    }
    public var synthesizer: AVSpeechSynthesizer!
    
    // MARK: - Private Properties
    private var commandResponse: [CommandResponse]!
    private var previousResponses = [String]()
    
    // MARK: - Setup
    public init() {
        setupNotificationsForSynthesizer()
    }
    
    // Observer that monitors a request to stop synthesizer from performing additional responses
    // Typically used to stop the synthesizer from responding to any incoming requests
    // that may have been queued or to interrupt a response in progress.
    private func setupNotificationsForSynthesizer() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self,
                                       selector: #selector(handleStopSynthesizer),
                                       name: .StopSynthesizer,
                                       object: nil)
    }
    
    // MARK: - Response Handler
    @objc
    func handleStopSynthesizer(notification: Notification) {
        stopSynthesizerWhenSpeaking()
    }
    // MARK: - Synthesizer Spoken Responses
    public func playResponse(to command: String) {
        guard let response = getResponse(to: command) else {
            commandNotFound(command)
            return
        }
        guard response != "duplicate" else { return }
        let utterance = AVSpeechUtterance(string: commandResponseBase.successfulResponse(command: command, response: response))
        synthesizer.speak(utterance)
    }
    
    private func commandNotFound(_ command: String) {
        let synthesizer = AVSpeechSynthesizer()
        let utterance = AVSpeechUtterance(string: commandResponseBase.commandNotFoundResponse(command: command))
        synthesizer.speak(utterance)
    }
}

// MARK: - Extensions
extension VoiceSynthesizer {
    // Responses that are repeated are ignored.
    // This may be necessary due to Speech Recognition issues.
    private func getResponse(to command: String) -> String? {
        let commandResponse = self.commandResponse.filter({ $0.command == command })
        if let response = commandResponse.first?.response {
            if previousResponses.contains(response) {
                return "duplicate"
            } else {
                previousResponses.append(response)
                return response
            }
        } else {
            return nil
        }
    }
    
    // Validate if the command is valid
    private func isValidCommand(_ command: String) -> Bool {
        return commandResponse.contains(where: {$0.command == command}) ? true : false
    }
    
    private func stopSynthesizerWhenSpeaking() {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .word)
        }
    }
    
}

extension Notification.Name {
    static let StopSynthesizer
        = NSNotification.Name("StopSynthesizer")
}
