import Foundation

public struct CommandResponse {
    public var command: String
    public var response: String
    
    public init(command: String, response: String) {
        self.command    = command
        self.response   = response
    }
}

public class CommandResponseAbstractClass {
    public func successfulResponse(command: String, response: String) -> String {
        return ""
    }
    public func commandNotFoundResponse(command: String) -> String {
        return ""
    }
    public func loadCommandResponse() -> [CommandResponse] {
        return [CommandResponse(command: "", response: "")]
    }
}
