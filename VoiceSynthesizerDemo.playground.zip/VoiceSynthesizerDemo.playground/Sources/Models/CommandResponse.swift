import Foundation

public struct CommandResponse {
    public var command: String
    public var response: String
    
    public init(command: String, response: String) {
        self.command    = command
        self.response   = response
    }
}

public class CommandResponseAbstractClass {
    // Response run through the Voice Synthesizer when a valid command has been entered
    public func successfulResponse(command: String, response: String) -> String {
        return ""
    }
    // Response run through the Voice Synthesizer when a valid command has NOT been entered
    public func commandNotFoundResponse(command: String) -> String {
        return ""
    }
    // Create a collection of Command/Response Items
    public func loadCommandResponse() -> [CommandResponse] {
        return [CommandResponse(command: "", response: "")]
    }
}
