/*:
 # Voice Synthesizer
 Takes a text string and speaks the result
 */
import UIKit
import AVFoundation
/*:
 ## Input
 Select one of the inputs below
 
 **State Capital**
 - Note: Choose a "State Name" and the capital city will be spoken
 
 **NFL Team**
 - Note: Choose a "Team Name" and the official home will be spoken
 */
/*:
 ````
 voice.commandResponseBase = StateCapitalManager()
 voice.commandResponseBase = NflTeamManager()
 ````
 */
let voice = VoiceSynthesizer()
voice.synthesizer = AVSpeechSynthesizer()
voice.commandResponseBase =  StateCapitalManager()
/*:
 ## Play a spoken response
 For instance....
 
 **State Capital**
 ````
 voice.playResponse(to: "Ohio")
 voice.playResponse(to: "Florida")
 voice.playResponse(to: "Oregon")
 voice.playResponse(to: "Texas")
 ````
 
 **NFL Team**
 ````
 voice.playResponse(to: "Bears")
 voice.playResponse(to: "Raiders")
 voice.playResponse(to: "Browns")
 voice.playResponse(to: "Patriots")
 ````
 */
voice.playResponse(to: "Ohio")
