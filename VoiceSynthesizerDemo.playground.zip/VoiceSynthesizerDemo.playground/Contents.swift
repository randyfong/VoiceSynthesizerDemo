/*:
 ## Voice Synthesizer
  Takes a text string and speaks the result
*/
import UIKit
import AVFoundation
/*:
 ### Input
 Select one of the inputs below
 1. State Capital
    - Choose a "State Name" and the capital city will be spoken
 2. NFL Team
    - Choose a "Team Name" and the official home will be spoken
*/
/*:
 Examples
 * voice.commandResponseBase = StateCapitalManager()
 * voice.commandResponseBase = NflTeamManager()
 */
let voice = VoiceSynthesizer()
voice.synthesizer = AVSpeechSynthesizer()
voice.commandResponseBase = StateCapitalManager()
/*:
 ### Play a spoken response
 For Instance....

 1. State Capital
 * voice.playResponse(to: "Ohio")
 * voice.playResponse(to: "Florida")
 * voice.playResponse(to: "Oregon")
 * voice.playResponse(to: "Texas")

 2. NFL Team
 * voice.playResponse(to: "Bears")
 * voice.playResponse(to: "Raiders")
 * voice.playResponse(to: "Browns")
 * voice.playResponse(to: "Patriots")
 */
voice.playResponse(to: "Ohio")
